cart = [{"name": "Laptop", "price": 1000}, {"name": "Phone", "price": 500}]
total = sum(item["price"] for item in cart)
print(f"Total: ${total}\nPayment successful!")
